<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "weconnect";

$conn = new mysqli($servername, $username, $password ,$db);
 
?>