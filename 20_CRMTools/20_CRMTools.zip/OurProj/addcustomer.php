<?php
 if (isset($_POST['abc'])) {
    $fullname = $_POST['account'];
    $company = $_POST['cid'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address= $_POST['address'];
    $city= $_POST['city'];
    $state= $_POST['state'];
    $zip= $_POST['zip'];
    $country= $_POST['country'];
    $currency= $_POST['currency'];
    $password= $_POST['password'];
    $confirmpassword= $_POST['cpassword'];
    include("Connectionfile.php");
    $sql = "Insert into customer (name,company,email,phone,address,city,state,zip,country,currency,password) VALUES('$fullname','$company','$email','$phone','$address','$city','$state','$zip','$country','$currency','$confirmpassword')";
    $result = $conn->query($sql);
    $conn->close();


 }
?>


<!DOCTYPE html>
<html>
   <head>
      <title>WeConnect</title>
      <meta http-equiv = "refresh" content = "3 ; url =../ACTPROJ/Customer/addcust.php" />
   </head>
   <body>
      <p style = "text-align:centre">User Successfully created</p>
   </body>
</html>





