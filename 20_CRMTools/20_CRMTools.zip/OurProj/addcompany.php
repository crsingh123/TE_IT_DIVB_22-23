<?php
 if (isset($_POST['abc'])) {
    $fullname = $_POST['account'];
    $url = $_POST['url'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    include("Connectionfile.php");
    $sql = "Insert into companies (companyname,url,email,phoneno) VALUES('$fullname','$url','$email','$phone')";
    $result = $conn->query($sql);
    $conn->close();
 }

if(isset($_POST['pqr']))
{?>
<!DOCTYPE html>
<html>
   <head>
      <title>WeConnect</title>
      <meta http-equiv = "refresh" content = "0; url =../ACTPROJ/Companies/companies.php" />
   </head>
   <body>
      <p style = "text-align:centre"></p>
   </body>
</html>
<?php

}

?>


<!DOCTYPE html>
<html>
   <head>
      <title>WeConnect</title>
      <meta http-equiv = "refresh" content = "3 ; url =../ACTPROJ/Companies/companies.php" />
   </head>
   <body>
      <p style = "text-align:centre">Company Successfully Added</p>
   </body>
</html>