<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>WeConnect</title>

    <link rel="apple-touch-icon" sizes="180x180" href="/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/icons/favicon-16x16.png">
    <link rel="manifest" href="/icons/site.webmanifest">
    <link rel="mask-icon" href="/icons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="/icons/favicon.ico">
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="msapplication-config" content="/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <link href="../weconnect.css" rel="stylesheet">
    <link href="../dark_extra.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="abc.css">

   
  <link rel="stylesheet" href="../plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
 
        
</head>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<body class="fixed-nav ">

<section>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">

                <ul class="nav" id="side-menu">

    <li class="nav-header">
        <div class="dropdown profile-element"> <span>

                        <img src="../default-user-avatar.png"  class="img-circle" style="max-width: 64px;" alt="">
                                                             </span>
            <a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Administrator</strong>
                             </span> <span class="text-muted text-xs block">My Account <b class="caret"></b></span> </span> </a>
            <ul class="dropdown-menu animated fadeIn m-t-xs">

          
                

                <li class="divider"></li>
                <li><a href="../Loginpage/loginpage.php">Logout</a></li>
            </ul>
        </div>
    </li>

    

            <li class="active"><a href="dashboard.php"></i> <span class="nav-label">Dashboard</span></a></li>
        

        <li class="">
        <a href="#"></i> <span class="nav-label">Customers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></a>
        <ul class="nav nav-second-level">
            <li><a href="../Customer/addcust.php">Add Customer</a></li>
            <li><a href="../Customer/listcust.php">List Customers</a></li>
           
                    </ul>
    </li>
    

        <li ><a href="../Companies/companies.php"> <span class="nav-label">Companies</span></a></li>
            

            <li class="">
                <a href="#"><span class="nav-label">Sales &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
                <ul class="nav nav-second-level">

                        <li><a href="../Sales/invoices.php">Invoices</a></li>
                        <li><a href="../Sales/newinvoice.php">New Invoice</a></li>
                        <li><a href="../Sales/recurinvo.php">Recurring Invoices</a></li>
                        <li><a href="../Sales/quotes.php">Quotes</a></li>
                        <li><a href="../Sales/newquotes.php">Create New Quote</a></li>
                        <li><a href="../Sales/quotesreq.php">Requested Quotes</a></li>

                </ul>
            </li>



            <li class="">
                <a href="#"></i> <span class="nav-label">Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
                <ul class="nav nav-second-level">
                
                    <li><a href="../Order/listorder.php">List All Orders</a></li>
                    <li><a href="../Order/addorder.php">Add New Order</a></li>
                    <li><a href="../Order/listorderreq.php">Requested Order</a></li>

                </ul>
            </li>
    
            <li class="">
            <a href="#"><span class="nav-label">Products & Services &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">
                <li><a href="../Pns/products.php">Products</a></li>
                <li><a href="../Pns/newproduct.php">New Product</a></li>
                

            </ul>
        </li>
            
            <li class="">
            <a href="#"> <span class="nav-label">Reports &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">


                <li><a href="../Reports/incomereports.php">Income Reports</a></li>
                <li><a href="../Reports/expense.php">Expense Reports</a></li>
                <li><a href="../Reports/incvsexp.php">Income Vs Expense</a></li>
                <li><a href="../Reports/alltransact.php">All Transactions</a></li>

            </ul>
            </li>

            
                <li class="" id="li_settings">
            <a href="#"> <span class="nav-label">Settings &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
            <ul class="nav nav-second-level">


                <li><a href="../Settings/paymeth.php">Payment Methods</a></li>
                
            </ul>
            </li>
    



</ul>

            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-fixed-top white-bg" role="navigation" style="margin-bottom: 0">

                    <img class="logo" style="max-height: 40px; width: auto;" src="abc.png" alt="Logo">

                  
                    
                    <ul class="nav navbar-top-links navbar-right pull-right">


                        <li class="dropdown navbar-user">

                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <img src="../default-user-avatar.png" alt="">
                                <span class="hidden-xs">Administrator</span> <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu animated fadeIn">
                                <li class="arrow"></li>

                          
                                
                                <li class="divider"></li>
                                <li><a href="../Loginpage/loginpage.php">Logout</a></li>

                            </ul>
                        </li>


                    </ul>

                </nav>
            </div>

            <div class="row wrapper white-bg page-heading">
                <div class="col-lg-12">
                    <h2 style="color: #2F4050; font-size: 16px; font-weight: 400; margin-top: 18px"> Dashboard </h2>

                </div>

            </div>

 <div class="wrapper wrapper-content animated fadeIn">
                
    <div class="row">
        <div class="col-md-12" id="ib_graph"></div>
        

    </div>

    <div class="row" id="sort_2">
        <!-- <div class="col-md-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Net Worth & Account Balances</h5>
                </div>
                <div class="ibox-content" style="min-height: 365px;">
                    <div>
                        <h3 class="text-center amount">0</h3>
                        <div>
                            <span class="amount">0</span> of <span class="amount">200000</span>
                            <small class="pull-right"><span class="amount">0.00</span>%</small>
                        </div>


                        <div class="progress progress-small">
                            <div style="width: 0.00%;" class="progress-bar progress-bar-danger"></div>
                        </div>
                    </div>
                    <table class="table table-striped table-bordered" style="margin-top: 26px;">
                        <th>Account</th>
                        <th class="text-right">Balance</th>
                        


                    </table>
                </div>
            </div>
        </div> -->
        


        <div class="col-md-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">

                    <h5>Income vs Expense - September 2022</h5>
                </div>
                <div class="ibox-content">
                    <div id="inc_exp_pie" style="height: 330px;">
                    <canvas id="myChart" style="width:100%;max-width:700px"></canvas>
                    </div>
                </div>
                
            </div>

        </div>
        <div class="container-fluid text-center">
        <img src="abc.png" class="img-rounded logo" style="width:40%; height: 40%; opacity: 0.5;" alt="logo" >
    </div>

    </div>
    
    </div>
    
        
    <div class="row" id="sort_4">


        <div class="col-md-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <a href="../Sales/invoices.php" class="btn btn-primary btn-xs pull-right"></i> Invoices</a>
                    <h5>Invoices</h5>
                </div>
                <div class="ibox-content">

                    <div id="invoice_stats" style="display: none;">

                    </div>
                    <h4>Recent Invoices</h4>
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Account</th>
                            <th>Amount</th>
                            <th>Invoice Date</th>
                            <th>Due Date</th>
                            <th width="110px;">Status</th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php
                                include("../../OurProj/Connectionfile.php");
                                $sql = "SELECT id,customer,total,date,duedate,status FROM invoices";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                }
                                $conn->close();
                                    
                                foreach ($options as $option)
                                 {
                                                ?>
                                        <tr> 
                                            <td> <?php echo $option['id'];?></td> 
                                            <td> <?php echo $option['customer'];?></td> 
                                            <td> <?php echo $option['total'];?></td>
                                            <td> <?php echo $option['date'];?></td>
                                            <td> <?php echo $option['duedate'];?></td> 
                                            <td> <?php echo $option['status'];?></td> 
                                             
                                        </tr>
                                <?php
                                 }
                            ?>
                        
                        </tbody>
                    </table>
                </div>
            </div>

        </div>


    </div>


    <div class="row" id="sort_3">
        <div class="col-md-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">

                    <h5>Latest Income</h5>
                </div>
                <div class="ibox-content">
                    <table class="table table-striped table-bordered">
                        <th>Credit</th>
                        <th>Date</th>
                        <?php
                                include("../../OurProj/Connectionfile.php");
                                $sql = "SELECT * FROM income";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                }
                                $conn->close();
                                    
                                foreach ($options as $option)
                                 {
                                                ?>
                                        <tr> 
                                            <td> <?php echo $option['money'];?></td> 
                                            <td> <?php echo $option['date'];?></td> 
                                        </tr>
                                <?php
                                 }
                            ?>
                        


                    </table>
                </div>
            </div>

        </div>


        <div class="col-md-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">

                    <h5>Latest Expense</h5>
                </div>
                <div class="ibox-content">
                    <table class="table table-striped table-bordered">
                        <th>Debit</th>
                        <th>Date</th>
                        <?php
                                include("../../OurProj/Connectionfile.php");
                                $sql = "SELECT * FROM expense";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                    // echo $options;
                                }
                                $conn->close();
                                    
                                foreach ($options as $option)
                                 {
                                                ?>
                                        <tr> 
                                            <td> <?php echo $option['money'];?></td> 
                                            <td> <?php echo $option['date'];?></td> 
                                            
                                        </tr>
                                <?php
                                 }
                            ?>
                            <tr>
                                <td colspan="7">
                                    <ul class="pagination">
                                    </ul>
                                </td>
                            </tr>

                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="container-fluid text-center">
        <img src="abc.png" class="img-rounded logo" style="width:25%; height: 25%; opacity: 0.5;" alt="logo" >
    </div> -->
</div>

                            
                            
        </div>


                    </div>
                </div>

            </div>



        </div>

    </div>
    
    
</section>


<script src="weconn.js"></script>


<!-- <script>
var xyValues = [
  {x:50, y:7},
  {x:60, y:8},
  {x:70, y:8},
  {x:80, y:9},
  {x:90, y:9},
  {x:100, y:9},
  {x:110, y:10},
  {x:120, y:11},
  {x:130, y:14},
  {x:140, y:14},
  {x:150, y:15},
  {x:130,y:0}
];

new Chart("myChart", {
  type: "scatter",
  data: {
    datasets: [{
      pointRadius: 4,
      pointBackgroundColor: "rgb(0,0,255)",
      data: xyValues
    }]
  },
  options: {
    legend: {display: false},
    scales: {
      xAxes: [{ticks: {min: 40, max:160}}],
      yAxes: [{ticks: {min: 6, max:16}}],
    }
  }
});
</script> -->

<?php 
                    include("../../OurProj/Connectionfile.php");
                    $sql = "SELECT money FROM income";
                    $sqll = "SELECT money FROM expense";
                    $result = $conn->query($sql);
                    $results = $conn->query($sqll);
                    if ($result->num_rows > 0) {
                        $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
                        $arr = [] ;
                        foreach($options as $option){array_push($arr,$option['money']);};
                        $aa = array_sum($arr);
                    }
                    if ($results->num_rows > 0) {
                        $optio= mysqli_fetch_all($results, MYSQLI_ASSOC);
                        $arry = [] ;
                        foreach($optio as $opti){array_push($arry,$opti['money']);};
                        $aab = array_sum($arry);
                    }
                    $conn->close();
?>



<script>
var xValues = [100,200,300,400,500,600,700,800,900,1000];

new Chart("myChart", {
  type: "line",
  data: {
    labels: xValues,
    datasets: [{ 

      data: <?php echo json_encode($arr) ?>,
      borderColor: "red",
      fill: false
    }, { 
      data:<?php echo json_encode($arry) ?> ,
      borderColor: "green",
      fill: false
    }]
  },
  options: {
    legend: {display: false}
  }
});
</script>

</body>

        </html>