var load_modules = function load_modules() {

    return true;

};
$(function() {

    var _url = $("#_url").val();
    var g_type = _url + 'dashboard' + '/';

    var ib_graph = $("#ib_graph");


    ib_graph.on('click', '.close', function(){
        $.post( _url+'settings/update_option/silent/', { opt: "ib_u_a", val: "0" })
            .done(function( data ) {

            });
    });

    $.post( g_type + "render/", { inner_graph: "canvas" })
        .done(function( render ) {

            ib_graph.html(render.msg);

        });

});