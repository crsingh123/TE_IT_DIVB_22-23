import os
import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as pl
from pandas.tseries.offsets import DateOffset

df=pd.read_csv('C:/xampp/htdocs/ACTPROJ/Sales/mydata.csv')

df.tail()

#dropping columns 105 & 106 since they contain bad data
df.drop(105,axis=0,inplace=True)
df.drop(106,axis=0,inplace=True)
# df.drop(107,axis=0,inplace=True)
# df.drop(108,axis=0,inplace=True)

df.tail()

#renaming column names of monthly sales
df.columns=['date','money' ]
df.head()

#converting month column to date time format
df['date']=pd.to_datetime(df['date'])
df.head()

#setting index as Month
df.set_index('date',inplace=True)
df.head()

#plotting the dataframe
df.plot()
pl.show()

#building arima model
model=sm.tsa.statespace.SARIMAX(df['money'],order=(1, 0, 0),seasonal_order=(1,1,1,12))
results=model.fit()

#forecasting present results to check
df['forecast']=results.predict(start=90,end=103,dynamic=True)
df[['money','forecast']].plot(figsize=(12,8))
pl.show()

#creating future dataset with 24 months values as NaN
future_dates=[df.index[-1]+ DateOffset(months=x)for x in range(0,24)]
future_df=pd.DataFrame(index=future_dates[1:],columns=df.columns)
future_df

#merging future_df and df
future=pd.concat([df,future_df])
future.head()

#forecasting future values
future['forecast'] = results.predict(start = 104, end = 120, dynamic= True)  
future[['money', 'forecast']].plot(figsize=(12, 8))
pl.show()