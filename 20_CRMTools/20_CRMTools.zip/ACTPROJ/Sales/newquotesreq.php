<!DOCTYPE html>
<?php 

session_start();

$idd = $_SESSION['ggg']

?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>WeConnect</title>

    <link rel="apple-touch-icon" sizes="180x180" href="/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/icons/favicon-16x16.png">
    <link rel="manifest" href="/icons/site.webmanifest">
    <link rel="mask-icon" href="/icons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="/icons/favicon.ico">
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="msapplication-config" content="/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <link href="../weconnect.css" rel="stylesheet">
    <link href="../dark_extra.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="modal.css" />
    <link rel="stylesheet" type="text/css" href="select2.min.css" />
    <link rel="stylesheet" type="text/css" href="select2.min.css" />
    <link rel="stylesheet" type="text/css" href="modal.css" />
    <link rel="stylesheet" type="text/css" href="datepicker.min.css" />
    <link rel="stylesheet" type="text/css" href="redactor.css" />
        
    <?php
        $success = NULL;
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if(isset($_POST['hrshtan'])){
                $date = date("d-m-Y");
                $expiry = $_POST['edate'];
                $stage = $_POST['stage'];
                $salestax = $_POST['tid'];
                $price = $_POST['amount'];
                $price1 = $_POST['amount1'];
                $price2 = $_POST['amount2'];
                $price3 = $_POST['amount3'];
                $totalind = $_POST['auth'];
                $totalind1 = $_POST['auth1'];
                $totalind2 = $_POST['auth2'];
                $totalind3 = $_POST['auth3'];
                $taxper = $_POST['taxed'];
                $taxper1 = $_POST['taxed1'];
                $taxper2 = $_POST['taxed2'];
                $taxper3 = $_POST['taxed3'];
                $subtotal = $_POST['ppp'];
                $taxamount = $_POST['lll'];
                $total = $_POST['kkk'];    

                include("../../OurProj/Connectionfile.php");
                $sql = "Update quotes set date ='$date',expiry ='$expiry',stage='$stage',salestax='$salestax',price='$price',totalind='$totalind',taxper='$taxper',price1='$price1',totalind1='$totalind1',taxper1='$taxper1',price2='$price2',totalind2='$totalind2',taxper2='$taxper2',price3='$price3',totalind3='$totalind3',taxper3='$taxper3',subtotal='$subtotal',taxamount='$taxamount',total='$total' where id = '$idd'";
                $result = $conn->query($sql);
                $conn->close();
                ?>
                <!DOCTYPE html>
                <html>
                    <meta http-equiv = "refresh" content = "0; url =../Sales/quotes.php"/>
                </html>
            <?php
            }
        }
        ?>  
    
</head>

<body class="fixed-nav ">
<section>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">

                <ul class="nav" id="side-menu">

    <li class="nav-header">
        <div class="dropdown profile-element"> <span>

                        <img src="../default-user-avatar.png"  class="img-circle" style="max-width: 64px;" alt="">
                                                             </span>
            <a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Administrator</strong>
                             </span> <span class="text-muted text-xs block">My Account <b class="caret"></b></span> </span> </a>
            <ul class="dropdown-menu animated fadeIn m-t-xs">

          
                

                <li class="divider"></li>
                <li><a href="../Loginpage/loginpage.php">Logout</a></li>
            </ul>
        </div>
    </li>

    

            <li class="active"><a href="../Dashboard/dashboard.php"></i> <span class="nav-label">Dashboard</span></a></li>
        

        <li class="">
        <a href="#"></i> <span class="nav-label">Customers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></a>
        <ul class="nav nav-second-level">
            <li><a href="../Customer/addcust.php">Add Customer</a></li>
            <li><a href="../Customer/listcust.php">List Customers</a></li>
            
                    </ul>
    </li>
    

        <li ><a href="../Companies/companies.php"> <span class="nav-label">Companies</span></a></li>
            

            <li class="">
                <a href="#"><span class="nav-label">Sales &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
                <ul class="nav nav-second-level">

                        <li><a href="../Sales/invoices.php">Invoices</a></li>
                        <li><a href="../Sales/newinvoice.php">New Invoice</a></li>
                        <li><a href="../Sales/recurinvo.php">Recurring Invoices</a></li>
                        <li><a href="../Sales/quotes.php">Quotes</a></li>
                        <li><a href="../Sales/newquotes.php">Create New Quote</a></li>
                        <li><a href="../Sales/quotesreq.php">Requested Quotes</a></li>

                </ul>
            </li>



            <li class="">
                <a href="#"></i> <span class="nav-label">Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
                <ul class="nav nav-second-level">
                
                    <li><a href="../Order/listorder.php">List All Orders</a></li>
                    <li><a href="../Order/addorder.php">Add New Order</a></li>
                    <li><a href="../Order/listorderreq.php">Requested Order</a></li>

                </ul>
            </li>
    
            <li class="">
            <a href="#"><span class="nav-label">Products & Services &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">
                <li><a href="../Pns/products.php">Products</a></li>
                <li><a href="../Pns/newproduct.php">New Product</a></li>

            </ul>
        </li>
            
            <li class="">
            <a href="#"> <span class="nav-label">Reports &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">


                <li><a href="../Reports/incomereports.php">Income Reports</a></li>
                <li><a href="../Reports/expense.php">Expense Reports</a></li>
                <li><a href="../Reports/incvsexp.php">Income Vs Expense</a></li>
                <li><a href="../Reports/alltransact.php">All Transactions</a></li>

            </ul>
            </li>

            
                <li class="" id="li_settings">
            <a href="#"> <span class="nav-label">Settings &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
            <ul class="nav nav-second-level">
                
                <li><a href="../Settings/paymeth.php">Payment Methods</a></li>
               
            </ul>
            </li>
    



</ul>

            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-fixed-top white-bg" role="navigation" style="margin-bottom: 0">

                    <img class="logo" style="max-height: 40px; width: auto;" src="abc.png" alt="Logo">

                  
                    
                    <ul class="nav navbar-top-links navbar-right pull-right">


                        <li class="dropdown navbar-user">

                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <img src="../default-user-avatar.png" alt="">
                                <span class="hidden-xs">Administrator</span> <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu animated fadeIn">
                                <li class="arrow"></li>

                          
                                
                                <li class="divider"></li>
                                <li><a href="../Loginpage/loginpage.php">Logout</a></li>

                            </ul>
                        </li>


                    </ul>

                </nav>
            </div>

            <div class="row wrapper white-bg page-heading">
                <div class="col-lg-12">
                    <h2 style="color: #2F4050; font-size: 16px; font-weight: 400; margin-top: 18px"></h2>

                </div>

            </div>

            <div class="wrapper wrapper-content animated fadeIn">
                
                

    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>
                        Requested Quote 
                    </h5>
                    <?php include("..\..\OurProj\Connectionfile.php")?>

<?php

$sql = "select * from quotes where id ='$idd'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    
    $conn->close();

?>

                </div>
                <div class="ibox-content" id="ibox_form">
                    <form id="invform" method="post">
                        <div class="ibox-content">
                            <div class="row">
                                <div class="alert alert-danger" id="emsg">
                                    <span id="emsgbody"></span>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="subject">Subject</label>
                                        <input type="text" readonly = "" class="form-control" name="subject" id="subject" value = "<?php foreach ($opt as $option) { echo $option['subject']; }  ?>">
                                    </div>
                                    <hr>
                                </div>
                            </div>

                            <div class="row">


                                <div class="col-md-6">
                                    <div class="form-horizontal">





                                        <div class="form-group">
                                            <label for="cid" class="col-sm-4 control-label">Customer</label>

                                            <div class="col-sm-8">
                                                
                                              

                                            <input type="text" readonly = "" class="form-control" name="cust" id="subject" value = "<?php foreach ($opt as $option) { echo $option['customer']; }  ?>">
                                                
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <label for="invoicenum"
                                                   class="col-sm-4 control-label">Quote Prefix</label>

                                            <div class="col-sm-4">
                                                <input type="text" readonly = "" class="form-control" name="subject" id="subject" value = "<?php foreach ($opt as $option) { echo $option['quoteprefix']; }  ?>">
                                            </div>
                                        </div>

                                        


                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-horizontal">
                                        <div class="form-group">
                                            <label for="inputEmail3"
                                                   class="col-sm-4 control-label">Date Created</label>

                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="idate" name="idate" datepicker
                                                data-date-format="dd-mm-yyyy" startDate ="<?php echo date("d-m-Y")?>" data-auto-close="true"
                                       value=<?php echo date("d-m-Y")?>>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="edate"
                                                   class="col-sm-4 control-label">Expiry Date</label>

                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="edate" name="edate" datepicker
                                                data-date-format="dd-mm-yyyy" startDate ="<?php echo date("d-m-Y")?>" data-auto-close="true"
                                       value=<?php echo date("d-m-Y")?>>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="stage"
                                                   class="col-sm-4 control-label">Stage</label>

                                            <div class="col-sm-8">
                                                <select class="form-control" name="stage" id="stage">
                                                    <option value="Draft">Draft</option>
                                                    <option value="Delivered">Delivered</option>
                                                    <option value="Accepted">Accepted</option>
                                                    <option value="Lost">Lost</option>
                                                    <option value="Dead">Dead</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="tid" class="col-sm-4 control-label">Sales TAX</label>

                                            <div class="col-sm-8">
                                                <select id="tid" name="tid" class="form-control">
                                                    <option value="">None</option>
                                                                                                            <option value="1">Sales Tax
                                                            (1.50
                                                            %)
                                                        </option>
                                                    
                                                </select>
                                                
                                            </div>
                                        </div>

                                        


                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <hr>
                                    <div class="form-group">
                                        <label for="proposal_text">Proposal Text</label>
                                        <textarea class="form-control" readonly="" id="proposal_text" name="proposal_text" rows="6"><?php foreach ($opt as $option) { echo $option['proposal']; } ?> </textarea>
                                        <span class="help-block">Displayed at the Top of the Quote</span>
                                    </div>
                                    <hr>
                                </div>
                            </div>



                            <div class="table-responsive m-t">
                                <table class="table invoice-table" id="invoice_items">
                                    <thead>
                                    <tr>
                                        <th width="60%">Item Name</th>
                                        <th width="10%">Qty</th>
                                        <th width="10%">Price</th>
                                        <th width="10%">Total</th>
                                        <th width="10%">Tax</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr> 
                                   
                                    <td><input type="text" readonly = "" class="form-control" name="subject" id="subject" value = "<?php foreach ($opt as $option) { echo $option['item']; }  ?>"></td> 
                                    <td><input type="text" readonly = ""id = "abc1" onchange="getChecked()" class="form-control qty" value = "<?php foreach ($opt as $option) { echo $option['quantity']; }  ?> "></td>
                                    <td><input type="text" id = "abc2" onchange="getChecked()" class="form-control item_price" name="amount" value=""></td> 
                                    <td><input type="text" id = "abc3" class="form-control lvtota" name="auth" readonly="" value= ""></td> 
                                    <td> <select class="form-control taxed" onchange="getChecked()"id= "abc4" name="taxed"> <option>6</option><option>12</option> <option>18</option></select></td>
                                </tr>
                            
                                    <tr> 
                                    
                                    <td><input type="text" readonly = "" class="form-control" name="subject" id="subject" value = "<?php foreach ($opt as $option) { echo $option['item1']; }  ?>"></td> 
                                    <td><input type="text" readonly = ""id = "abc11" onchange="getChecked()" class="form-control qty" value = "<?php foreach ($opt as $option) { echo $option['quantity1']; }  ?> "></td>
                                    <td><input type="text" id = "abc12" onchange="getChecked()" class="form-control item_price" name="amount1" value=""></td> 
                                    <td><input type="text" id = "abc13" class="form-control lvtota" readonly="" name="auth1" value= ""></td> 
                                    <td> <select class="form-control taxed" onchange="getChecked()"id= "abc14" name="taxed1"> <option>6</option><option>12</option> <option>18</option></select></td>
                                </tr>

                                <tr> 
                                <td><input type="text" readonly = "" class="form-control" name="subject" id="subject" value = "<?php foreach ($opt as $option) { echo $option['item2']; }  ?>"></td> 
                                    <td><input type="text" readonly = ""id = "abc21" onchange="getChecked()" class="form-control qty" value = "<?php foreach ($opt as $option) { echo $option['quantity2']; }  ?> "></td>
                                    <td><input type="text" id = "abc22" onchange="getChecked()" class="form-control item_price" name="amount2" value=""></td> 
                                    <td><input type="text" id = "abc23" class="form-control lvtota" name="auth2" readonly="" value= ""></td> 
                                    <td> <select class="form-control taxed" onchange="getChecked()"id= "abc24" name="taxed2"> <option>6</option><option>12</option> <option>18</option></select></td>
                                </tr>

                                <tr> 
                                    
                                <td><input type="text" readonly = "" class="form-control" name="subject" id="subject" value = "<?php foreach ($opt as $option) { echo $option['item3']; }  ?>"></td> 
                                    <td><input type="text" readonly = ""id = "abc31" onchange="getChecked()" class="form-control qty" value = "<?php foreach ($opt as $option) { echo $option['quantity3']; }  ?> "></td>
                                    <td><input type="text" id = "abc32" onchange="getChecked()" class="form-control item_price" name="amount3" value=""></td> 
                                    <td><input type="text" id = "abc33" class="form-control lvtota" name="auth3" readonly="" value= ""></td> 
                                    <td> <select class="form-control taxed" onchange="getChecked()"id= "abc34" name="taxed3"> <option>6</option><option>12</option> <option>18</option></select></td>
                                </tr>

                                    </tbody>
                                </table>

                                <hr>

                            </div>
                            <!-- /table-responsive -->
                            
                            
                    
                            <table class="table invoice-total">
                                <tbody>
                                <tr>
                                <td><strong>Sub Total (₹):</strong></td>
                                <td>
                                
                                <input  name="ppp" id="pqr" readonly=""value="">
                                </td>
                                
                            </tr>
                            <tr>
                                <td><strong>TAX (₹):</strong></td>
                                <td>
                                
                                <input id="pqr1"name="lll" readonly=""value="">
                                </td>
                            </tr>
                            <tr>
                                <td><strong>TOTAL (₹):</strong></td>
                                <td>
                               
                                <input id="pqr2" name="kkk" readonly=""value="">
                                </td>
                            </tr>
                                </tbody>
                            </table>
                            <hr>

                            <div class="form-group">
                                <label for="customer_notes">Customer Notes</label>
                                <textarea readonly ="" class="form-control" id="customer_notes" name="customer_notes" rows="6"><?php foreach ($opt as $option) { echo $option['custnot']; }  ?></textarea>
                                <span class="help-block">Displayed as a Footer to the Quote</span>
                            </div>

                            <div class="text-right">
                                <input type="hidden" id="_dec_point" name="_dec_point" value=".">
                                <input type="hidden" id="taxed_type" name="taxed_type" value="individual">
                                <button class="btn btn-primary" name="hrshtan" id="subm" method ="post"> Save</button>
                            </div>


                        </div>
                    </form>


                </div>
            </div>
        </div>

    </div>

   




                <div id="ajax-modal" class="modal container fade-scale" tabindex="-1" style="display: none;"></div>
            </div>

                            
                            
        </div>

    </div>

<script src="weconnect.js"></script>



    <script  src="redactor.min.js"></script>
        <script  src="select2.min.js"></script>
        <script  src="en.js"></script>
        <script  src="datepicker.min.js"></script>
        <script  src="en (2).js"></script>
        <script  src="numeric.js"></script>
        <script  src="modal.js"></script>
        <script  src="quotes.js"></script>
        
<script>        
function getChecked() {

  //1
  const quan = document.getElementById('abc1').value;
  const pri = document.getElementById('abc2').value;
  const aaa = quan*pri ;
  const checkBox = document.getElementById('abc3').value = aaa ;
  const taxper = document.getElementById('abc4').value;
  const aab = taxper*(quan*pri)/100 ;
  //2
  const quan2 = document.getElementById('abc11').value;
  const pri2 = document.getElementById('abc12').value;
  const aaa2 = quan2*pri2 ;
  const checkBox2 = document.getElementById('abc13').value = aaa2 ;
  const taxper2 = document.getElementById('abc14').value;
  const aab2 = taxper2*(quan2*pri2)/100 ;
  //3
  const quan3 = document.getElementById('abc21').value;
  const pri3 = document.getElementById('abc22').value;
  const aaa3 = quan3*pri3 ;
  const checkBox3 = document.getElementById('abc23').value = aaa3 ;
  const taxper3 = document.getElementById('abc24').value;
  const aab3 = taxper3*(quan3*pri3)/100 ;
  //4
  const quan4 = document.getElementById('abc31').value;
  const pri4 = document.getElementById('abc32').value;
  const aaa4 = quan4*pri4 ;
  const checkBox4 = document.getElementById('abc33').value = aaa4 ;
  const taxper4 = document.getElementById('abc34').value;
  const aab4 = taxper4*(quan4*pri4)/100 ;

  const check = document.getElementById('pqr').value = parseInt(aaa)+parseInt(aaa2)+parseInt(aaa3)+parseInt(aaa4) ;
  const checkB = document.getElementById('pqr1').value = parseFloat(aab)+parseFloat(aab2)+parseFloat(aab3)+parseFloat(aab4) ;
  const aac =  parseInt(check)+ parseFloat(checkB) ;
  const che = document.getElementById('pqr2').value = aac ;

};
</script>



</body>

</html>