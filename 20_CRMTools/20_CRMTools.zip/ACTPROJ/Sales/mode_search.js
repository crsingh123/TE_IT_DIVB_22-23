$(function () {
    $('.footable').footable();
});