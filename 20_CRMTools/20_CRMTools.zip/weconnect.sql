-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2023 at 10:48 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `weconnect`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(6) UNSIGNED NOT NULL,
  `companyname` varchar(100) NOT NULL,
  `url` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phoneno` varchar(100) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `companyname`, `url`, `email`, `phoneno`, `reg_date`) VALUES
(8, 'AJH Exports', 'http://ajhexports.in', 'ceo_ajhexports@ajhexports.co.in', '7894561230', '2023-02-22 04:42:58'),
(9, 'Sky Scanner Pvt Ltd', 'http://skyscanner.in', 'ceo_skyscanner@skyscanner.co.in', '7894561236', '2023-02-22 04:51:01');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `name` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`name`, `company`, `email`, `phone`, `address`, `city`, `state`, `zip`, `country`, `currency`, `password`) VALUES
('Atharv Sathe', 'AJH Exports', 'atharvsathe@ajhexports.co.in', '9764421566', 'Vardayini', 'Thane', 'Maharashtra', '400602', 'India', 'INR', '123456'),
('Dhananjay Phalke', 'Sky Scanner Pvt Ltd', 'dhananjayphalke@skyscanner.co.in', '7894561230', 'Runwal', 'Thane', 'Maharashtra', '400602', 'India', 'INR', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `money` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`money`, `date`) VALUES
(1000, '20-04-2023'),
(3000, '19-04-2023\r\n'),
(1000, '20-04-2023'),
(3000, '19-04-2023\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `money` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`money`, `date`) VALUES
(5300, '20-04-2023'),
(3360, '20-04-2023'),
(2240, '20-04-2023');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `totalind` varchar(255) DEFAULT NULL,
  `taxper` varchar(255) DEFAULT NULL,
  `item1` varchar(255) DEFAULT NULL,
  `quantity1` varchar(255) DEFAULT NULL,
  `price1` varchar(255) DEFAULT NULL,
  `totalind1` varchar(255) DEFAULT NULL,
  `taxper1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `quantity2` varchar(255) DEFAULT NULL,
  `price2` varchar(255) DEFAULT NULL,
  `totalind2` varchar(255) DEFAULT NULL,
  `taxper2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `quantity3` varchar(255) DEFAULT NULL,
  `price3` varchar(255) DEFAULT NULL,
  `totalind3` varchar(255) DEFAULT NULL,
  `taxper3` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `customer` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `duedate` varchar(255) DEFAULT NULL,
  `salestax` varchar(255) DEFAULT NULL,
  `invoterm` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `item`, `quantity`, `price`, `totalind`, `taxper`, `item1`, `quantity1`, `price1`, `totalind1`, `taxper1`, `item2`, `quantity2`, `price2`, `totalind2`, `taxper2`, `item3`, `quantity3`, `price3`, `totalind3`, `taxper3`, `subtotal`, `taxamount`, `total`, `customer`, `email`, `status`, `date`, `duedate`, `salestax`, `invoterm`) VALUES
(1, 'Shoes', '10', '100', '1000', '18', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '1000', '180', '1180', 'Atharv Sathe', 'atharvsathe@ajhexports.co.in', 'Unpaid', '20-04-2023', 'due_on_receipt', '', ''),
(2, 'Bag', '100', '50', '5000', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '5000', '300', '5300', 'Atharv Sathe', 'atharvsathe@ajhexports.co.in', 'Paid', '20-04-2023', 'due_on_receipt', '', ''),
(3, 'Purse', '100', '20', '2000', '12', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '2000', '240', '2240', 'Atharv Sathe', 'atharvsathe@ajhexports.co.in', 'Unpaid', '20-04-2023', 'due_on_receipt', '', ''),
(4, 'Belt', '10', '300', '3000', '12', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '3000', '360', '3360', 'Atharv Sathe', 'atharvsathe@ajhexports.co.in', 'Paid', '20-04-2023', 'due_on_receipt', '', ''),
(5, 'Shoes', '10', '200', '2000', '12', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '2000', '240', '2240', 'Atharv Sathe', 'atharvsathe@ajhexports.co.in', 'Paid', '20-04-2023', 'due_on_receipt', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `products` varchar(100) DEFAULT NULL,
  `customer` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `billing` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `products`, `customer`, `email`, `status`, `price`, `billing`, `date`) VALUES
(1, 'Wallet', 'Atharv Sathe', 'atharvsathe@ajhexports.co.in', 'xx', NULL, NULL, '20-04-2023');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `paymeth` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`paymeth`) VALUES
('UPI'),
('Card'),
('Net Banking');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `name` varchar(100) NOT NULL,
  `sprice` varchar(100) NOT NULL,
  `itemno` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`name`, `sprice`, `itemno`, `description`) VALUES
('Shoes', '', '45', 'Stunning shoes with Best grip and Best comfort '),
('Bag', '', '12', 'Rough and Tough Travelbackpack'),
('Wallet', '', '78', 'Mens Wallet'),
('Belt', '', '55', 'Mens Belt'),
('Purse', '', '22', 'Womens Purse');

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `customer` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `expiry` varchar(255) DEFAULT NULL,
  `quoteprefix` varchar(255) DEFAULT NULL,
  `quote` varchar(255) DEFAULT NULL,
  `stage` varchar(255) DEFAULT NULL,
  `salestax` varchar(255) DEFAULT NULL,
  `proposal` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `totalind` varchar(255) DEFAULT NULL,
  `taxper` varchar(255) DEFAULT NULL,
  `item1` varchar(255) DEFAULT NULL,
  `quantity1` varchar(255) DEFAULT NULL,
  `price1` varchar(255) DEFAULT NULL,
  `totalind1` varchar(255) DEFAULT NULL,
  `taxper1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `quantity2` varchar(255) DEFAULT NULL,
  `price2` varchar(255) DEFAULT NULL,
  `totalind2` varchar(255) DEFAULT NULL,
  `taxper2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `quantity3` varchar(255) DEFAULT NULL,
  `price3` varchar(255) DEFAULT NULL,
  `totalind3` varchar(255) DEFAULT NULL,
  `taxper3` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `custnot` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quotes`
--

INSERT INTO `quotes` (`id`, `subject`, `customer`, `email`, `date`, `expiry`, `quoteprefix`, `quote`, `stage`, `salestax`, `proposal`, `item`, `quantity`, `price`, `totalind`, `taxper`, `item1`, `quantity1`, `price1`, `totalind1`, `taxper1`, `item2`, `quantity2`, `price2`, `totalind2`, `taxper2`, `item3`, `quantity3`, `price3`, `totalind3`, `taxper3`, `subtotal`, `taxamount`, `total`, `custnot`) VALUES
(1, 'Quote Request', 'Atharv Sathe', 'atharvsathe@ajhexports.co.in', NULL, NULL, NULL, NULL, NULL, NULL, 'Na', 'Bag', '10', NULL, NULL, NULL, 'Select', '1', NULL, NULL, NULL, 'Select', '1', NULL, NULL, NULL, 'Select', '1', NULL, NULL, NULL, NULL, NULL, 'xx', 'NA'),
(2, 'Quote Request', 'Atharv Sathe', 'atharvsathe@ajhexports.co.in', NULL, NULL, NULL, NULL, NULL, NULL, 'NA', 'Belt', '10', NULL, NULL, NULL, 'Select', '1', NULL, NULL, NULL, 'Select', '1', NULL, NULL, NULL, 'Select', '1', NULL, NULL, NULL, NULL, NULL, 'xx', 'NA'),
(3, 'Quote Request', 'Atharv Sathe', 'atharvsathe@ajhexports.co.in', '20-04-2023', '20-04-2023', NULL, NULL, 'Draft', '', '', 'Shoes', '10', '200', '2000', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '2000', '120', '2120', 'NA');

-- --------------------------------------------------------

--
-- Table structure for table `reqquote`
--

CREATE TABLE `reqquote` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `customer` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `proposal` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `item1` varchar(255) DEFAULT NULL,
  `quantity1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `quantity2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `quantity3` varchar(255) DEFAULT NULL,
  `custnot` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotes`
--
ALTER TABLE `quotes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reqquote`
--
ALTER TABLE `reqquote`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quotes`
--
ALTER TABLE `quotes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reqquote`
--
ALTER TABLE `reqquote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
