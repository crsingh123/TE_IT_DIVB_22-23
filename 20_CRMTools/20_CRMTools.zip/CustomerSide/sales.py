import pandas as pd
import numpy as np
import matplotlib.pylab as plt
%matplotlib inline