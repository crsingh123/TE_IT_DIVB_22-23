<?php $loguser = "atharvsathe11@gmail.com";?>
<?php include("../../OurProj/Connectionfile.php");
    $sql = "SELECT * FROM customer where email='$loguser'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    $conn->close();
        ?>