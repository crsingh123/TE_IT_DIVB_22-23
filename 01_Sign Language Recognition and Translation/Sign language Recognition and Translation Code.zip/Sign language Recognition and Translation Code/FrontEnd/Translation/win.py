import tkinter as tk
import nltk
import cv2
from PIL import Image
import os
from nltk.stem import WordNetLemmatizer
from PIL import ImageTk
# nltk.download('punkt')
from tkinter import messagebox
import requests
from io import BytesIO
import spacy
from spacy.tokens import Doc
root = tk.Tk()
# nlp = spacy.load('en_core_web_sm')
# canvas = tk.Canvas(root, width=640, height=480)
# canvas.pack()

# Load the NLP model
nlp = spacy.load('en_core_web_sm')
# Create the main window
# root = tk.Tk()
root.title("Translate")
root.geometry("500x300+200+100")

def fetch_and_display_images():
    # Get the text from the text field
    text = text_field.get()
    keywords = process_text(text)
    matches = fetch_images(keywords)
    if matches:
        display_images(matches)
    else:
        messagebox.showinfo("No Matches Found", "No matching images were found in the folder.")

def process_text(text):
    lemmatizer = WordNetLemmatizer()
    tokens = nltk.word_tokenize(text.lower())
    tagged_tokens = nltk.pos_tag(tokens)
    keywords = []
    for i in range(len(tagged_tokens)):
        token = tagged_tokens[i][0]
        pos = tagged_tokens[i][1]
        if token.isalnum():
            if pos.startswith('NN') or pos.startswith('JJ') or pos.startswith('VB'):
                keyword = lemmatizer.lemmatize(token)
                if token in keywords:
                    continue
                if i < len(tagged_tokens) - 1 and tagged_tokens[i+1][1].startswith('NN'):
                    # If the current token is an adjective or verb, and the next token is a noun,
                    # combine them into a single keyword
                    keyword += ' ' + lemmatizer.lemmatize(tagged_tokens[i+1][0])
                keywords.append(keyword)
    return keywords

def fetch_images(keywords):
    image_folder = 'FrontEnd/Translation/Images'
    matches = []
    for file in os.listdir(image_folder):
        if file.endswith('.jpg') or file.endswith('.jpeg') or file.endswith('.PNG') or file.endswith('.png'):
            image_name = os.path.splitext(file)[0]
            image_keywords = process_text(image_name)
            print('Image Name:', image_name, 'Keywords:', image_keywords)
            print(f"Image Name: {image_name} Keywords: {image_keywords}")
            print(f"Search Keywords: {keywords}")
            if all(keyword in image_keywords for keyword in keywords):
                matches.append(os.path.join(image_folder, file))
    print('Matches:', matches)
    return matches

def display_images(matches):
    # new_window = tk.Toplevel(root)
    # new_window.title('Matching Images')
    # row, col = 0, 0
    # for match in matches:
    #     img = Image.open(match)
    #     img = img.resize((100, 100), Image.ANTIALIAS)
    #     photo = ImageTk.PhotoImage(img)
    #     label = tk.Label(new_window, image=photo)
    #     label.image = photo
    #     label.grid(row=row, column=col, padx=10, pady=10)
    #     col += 1
    #     if col > 3:
    #         col = 0
    #         row += 1
    global image_label
    if image_label:
        image_label.destroy()
    image_label = tk.Label(root)
    image_label.place(relx=0.5, rely=0.66, anchor="center")
    for match in matches:
        img = Image.open(match)
        img = img.resize((250, 150), Image.ANTIALIAS)
        photo = ImageTk.PhotoImage(img)
        image_label.configure(image=photo)
        image_label.image = photo
            
# Create a label with the heading
heading = tk.Label(root, text="Translate", font=("Helvetica", 18))
heading.place(relx=0.5, rely=0.1, anchor="center")

# Create a text field
text_field = tk.Entry(root, font=('Helvetica', 16))
text_field.place(relx=0.5, rely=0.2, anchor="center")
# text_field.pack()

# Create a button
button = tk.Button(root, text="Translate",command=fetch_and_display_images)
button.place(relx=0.5, rely=0.3, anchor="center")
image_label = tk.Label(root)
image_label.place(relx=0.5, rely=0.5, anchor="center")
# Run the main event loop
root.mainloop()