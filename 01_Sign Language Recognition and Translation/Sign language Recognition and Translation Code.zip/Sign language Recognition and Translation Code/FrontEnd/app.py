from flask import Flask, render_template
import subprocess

app = Flask(__name__, template_folder='templates')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/feed.html')
def feed():
    return render_template('feed.html')

@app.route('/recc.html')
def recc():
    return render_template('recc.html')

@app.route('/text.html')
def text():
    return render_template('text.html')

@app.route('/num_pre')
def num_rec():
    subprocess.run(['python', 'FrontEnd/Recognition/num_predict.py'])
    # Pass a message to the template to let the user know that the script has finished
    result = 'Sign language recognition complete'
    return render_template('recc.html',result=result)

@app.route('/alpha_rec')
def alpha_rec():
    subprocess.run(['python', 'FrontEnd/Recognition/alpha_predict.py'])
    # Pass a message to the template to let the user know that the script has finished
    result = 'Sign language recognition complete'
    return render_template('recc.html',result=result)

@app.route('/word_py')
def word_py():
    subprocess.run(['python', 'FrontEnd/Translation/win.py'])
    # Pass a message to the template to let the user know that the script has finished
    result = 'Sign language Translation complete'
    return render_template('text.html',result=result)


if __name__ == '__main__':
    app.run(debug=False)
