import cv2
import numpy as np
from keras.models import load_model

# Load the pre-trained VGG16 model for sign language recognition
model = load_model('FrontEnd/Recognition/aplha_model_vgg16.h5')

# Define a function to preprocess the input image
def preprocess_image(image):
    # Preprocess the input image as required by your model (e.g. resize, normalize, etc.)
    image = cv2.resize(image, (64, 64))
    image = image.astype("float32") / 255.0
    image = np.expand_dims(image, axis=0)
    return image

# Define a dictionary to map the predicted class to an alphabet
alphabet_map = {0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E', 5: 'F', 6: 'G', 7: 'H', 8: 'I', 9: 'J', 10: 'K', 11: 'L', 12: 'M', 13: 'N', 14: 'O', 15: 'P', 16: 'Q', 17: 'R', 18: 'S', 19: 'T', 20: 'U', 21: 'V', 22: 'W', 23: 'X', 24: 'Y', 25: 'Z'}

# Open a video capture object for the default camera
cap = cv2.VideoCapture(0)

# Define the ROI box coordinates
x, y, w, h = 100, 100, 200, 200

# Loop over frames from the video stream
while True:
    # Read a frame from the video stream
    ret, frame = cap.read()

    # Check if a frame was successfully read
    if ret:
        # Extract the ROI from the frame
        roi = frame[y:y+h, x:x+w]

        # Preprocess the ROI
        image = preprocess_image(roi)

        # Use the pre-trained model to make a prediction on the ROI
        prediction = model.predict(image)

        # Map the predicted class to an alphabet using the dictionary
        alphabet = alphabet_map[np.argmax(prediction)]

        # Draw the ROI box on the frame
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Draw the predicted alphabet on the frame
        cv2.putText(frame, alphabet, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Show the frame with the predicted alphabet
        cv2.imshow('Sign Language Alphabet Recognition', frame)

        # Exit the program if the user presses the 'q' key
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

# Release the video capture object and close the window
cap.release()
cv2.destroyAllWindows()
