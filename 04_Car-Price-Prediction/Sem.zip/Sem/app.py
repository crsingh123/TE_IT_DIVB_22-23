from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re
import requests
import pickle
import numpy as np
import sklearn 
from sklearn.preprocessing import StandardScaler
import datetime
 
 
app = Flask(__name__, static_url_path='/static')
 
 
app.secret_key = 'xyzsdfg'
 
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Shivam_2001'
app.config['MYSQL_DB'] = 'usersystem'
 
mysql = MySQL(app)
model = pickle.load(open('random_forest_regression_model.pkl', 'rb'))

@app.route('/')
def start():
    return redirect('/login')

@app.route('/home',methods=['GET','POST'])
def homepage():
    return render_template('index.html')

@app.route('/login', methods =['GET', 'POST'])
def login():
    mesage = ''
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        email = request.form['email']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE email = % s AND password = % s', (email, password, ))
        user = cursor.fetchone()
        if user:
            session['loggedin'] = True
#             session['userid'] = user['userid']
            session['password'] = user['password']
            session['email'] = user['email']
            mesage = 'Logged in successfully !'
            return redirect('/home')
        else:
            mesage = 'Please enter correct email / password !'
    return render_template('login.html', mesage = mesage)
 
@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('userid', None)
    session.pop('email', None)
    return redirect(url_for('login'))
 
@app.route('/register', methods =['GET', 'POST'])
def register():
    mesage = ''
    if request.method == 'POST' and 'name' in request.form and 'password' in request.form and 'email' in request.form and 'phone_no' in request.form :
        userName = request.form['name']
        password = request.form['password']
        email = request.form['email']
        phone_no = request.form['phone_no']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE email = % s', (email, ))
        account = cursor.fetchone()
        if account:
            mesage = 'Account already exists !'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            mesage = 'Invalid email address !'
        elif not userName or not password or not email:
            mesage = 'Please fill out the form !'
        else:
            cursor.execute('INSERT INTO user VALUES ( % s, % s, % s, % s)', (userName, email, password, phone_no ))
            mysql.connection.commit()
            mesage = 'You have successfully registered !'
            return redirect('/login')
    elif request.method == 'POST':
        mesage = 'Please fill out the form !'
    return render_template('register.html', mesage = mesage)

@app.route("/predict", methods=['GET','POST'])
def predict():
    Fuel_Type_Diesel=0
    if request.method == 'POST':
        Year = int(request.form['Year'])
        Present_Price=float(request.form['Present_Price'])
        Kms_Driven=int(request.form['Kms_Driven'])
        Kms_Driven2=np.log(Kms_Driven)
        Owner=int(request.form['Owner'])
        Fuel_Type_Petrol=request.form['Fuel_Type_Petrol']
        if(Fuel_Type_Petrol=='Petrol'):
                Fuel_Type_Petrol=1
                Fuel_Type_Diesel=0
        else:
            Fuel_Type_Petrol=0
            Fuel_Type_Diesel=1
        Year=2023-Year
        Seller_Type_Individual=request.form['Seller_Type_Individual']
        if(Seller_Type_Individual=='Individual'):
            Seller_Type_Individual=1
        else:
            Seller_Type_Individual=0  
        Transmission_Mannual=request.form['Transmission_Mannual']
        if(Transmission_Mannual=='Mannual'):
            Transmission_Mannual=1
        else:
            Transmission_Mannual=0
        prediction=model.predict([[Present_Price,Kms_Driven2,Owner,Year,Fuel_Type_Diesel,Fuel_Type_Petrol,Seller_Type_Individual,Transmission_Mannual]])
        output=round(prediction[0],2)
        if output<0:
            return render_template('index.html',prediction_texts="Sorry you cannot sell this car")
        else:
            return redirect(url_for('result', prediction_text=output))
    else:
        return render_template('index.html')

@app.route("/resetpassword")
def forgot():
    return render_template('forgot.html')

@app.route("/result")
def result():
    prediction_text = request.args.get('prediction_text')
    return render_template('result.html',prediction_text=prediction_text)

@app.route("/signup")
def reg():
    return render_template("signup.html")

if __name__ == "__main__":
    app.run()