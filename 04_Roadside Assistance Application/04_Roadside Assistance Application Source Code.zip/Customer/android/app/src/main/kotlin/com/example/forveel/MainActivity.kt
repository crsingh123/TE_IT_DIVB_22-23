package com.example.forveel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
