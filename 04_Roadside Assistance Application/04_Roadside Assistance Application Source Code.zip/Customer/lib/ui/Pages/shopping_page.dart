import 'package:flutter/material.dart';
import 'package:forveel/ui/Mycolors.dart';

class ShoppingPage extends StatefulWidget {
  @override
  _ShoppingPageState createState() => _ShoppingPageState();
}

class _ShoppingPageState extends State<ShoppingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
body: Container(
  alignment: Alignment.center,
  child: Text("RSA",style: TextStyle(color: textc),),
),
    );
  }
}
