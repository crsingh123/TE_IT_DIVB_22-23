from tkinter import*
from tkinter import ttk
from PIL import Image , ImageTk
from tkinter import messagebox
import mysql.connector
import cv2
from face_recognition import Face_Recognition
from login import Login_Window

class First:
    def __init__(self , root):
        self.root= root
        self.root.geometry("1530x790+0+0")
        self.root.title(" Face Recognition System")
        img3 =Image.open(r"E:\\python project (2)\\python project\\img\\bg.jpg")
        img3=img3.resize((1530,800),Image.ANTIALIAS)
        self.photoimg3 = ImageTk.PhotoImage(img3)

        bg_img=Label(self.root,image=self.photoimg3)
        bg_img.place(width=1530,height=800)
        
        btn_frame=Frame(self.root)
        btn_frame.place(x=450,y=300,width=500,height=100)

        save_btn=Button(btn_frame , text="Mark Attendencce"  ,command = self.face ,width=50 ,font =("times new roman",13,"bold"),bg ="white")
        save_btn.grid(row=0,column=0)

        update_btn=Button(btn_frame,text="Login" ,command=self.login ,width=50,font=("times new roman",13,"bold"),bg ="white")
        update_btn.grid(row=2,column=0,pady=20)
        
    def face(self):
        self.new_window = Toplevel(self.root)
        self.app = Face_Recognition(self.new_window)

    def login(self):
        self.new_window = Toplevel(self.root)
        self.app = Login_Window(self.new_window)


if __name__ == "__main__":
    root = Tk()
    obj= First(root)
    root.mainloop()
