import mysql.connector
import tkinter as tk
from tkinter import messagebox

# Connect to MySQL database
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="vaishu0305",
    database="face"
)

# Create cursor
mycursor = mydb.cursor()

# Create login window
class LoginWindow(tk.Tk):
    def __init__(self):
        super().__init__()

        # Set window properties
        self.title("Login Page")
        self.geometry("400x300")

        # Create username and password labels and entries
        self.lblusername = tk.Label(self, text="Username")
        self.lblusername.grid(row=0, column=0, padx=10, pady=10)
        self.txtusername = tk.Entry(self)
        self.txtusername.grid(row=0, column=1, padx=10, pady=10)

        self.lblpassword = tk.Label(self, text="Password")
        self.lblpassword.grid(row=1, column=0, padx=10, pady=10)
        self.txtpassword = tk.Entry(self, show="*")
        self.txtpassword.grid(row=1, column=1, padx=10, pady=10)

        # Create login button
        self.btnlogin = tk.Button(self, text="Login", command=self.login)
        self.btnlogin.grid(row=2, column=1, padx=10, pady=10)

    # Validate login credentials
    def login(self):
        username = self.txtusername.get()
        password = self.txtpassword.get()

        mycursor.execute("SELECT * FROM login WHERE uname = %s AND pass = %s", (username, password))
        result = mycursor.fetchone()

        if result:
            messagebox.showinfo("Success", "Login successful!")
        else:
            messagebox.showerror("Error", "Invalid username or password.")

# Create registration window
class RegisterWindow(tk.Tk):
    def __init__(self):
        super().__init__()

        # Set window properties
        self.title("Registration Page")
        self.geometry("400x300")

        # Create username, email, and password labels and entries
        self.lblusername = tk.Label(self, text="Username")
        self.lblusername.grid(row=0, column=0, padx=10, pady=10)
        self.txtusername = tk.Entry(self)
        self.txtusername.grid(row=0, column=1, padx=10, pady=10)

        self.lblemail = tk.Label(self, text="Email")
        self.lblemail.grid(row=1, column=0, padx=10, pady=10)
        self.txtemail = tk.Entry(self)
        self.txtemail.grid(row=1, column=1, padx=10, pady=10)

        self.lblpassword = tk.Label(self, text="Password")
        self.lblpassword.grid(row=2, column=0, padx=10, pady=10)
        self.txtpassword = tk.Entry(self, show="*")
        self.txtpassword.grid(row=2, column=1, padx=10, pady=10)

        # Create register button
        self.btnregister = tk.Button(self, text="Register", command=self.register)
        self.btnregister.grid(row=3, column=1, padx=10, pady=10)

    # Validate and insert registration data into database
    def register(self):
        username = self.txtusername.get()
        email = self.txtemail.get()
        password = self.txtpassword.get()

        # Validate registration data
        if username == "" or email == "" or password == "":
                messagebox.showerror("Error", "Please fill in all fields.")
        elif len(username) < 4 or len(username) > 20:
                messagebox.showerror("Error", "Username must be between 4 and 20 characters.")
        elif not any(char.isdigit() for char in password):
                messagebox.showerror("Error", "Password must contain at least one digit.")
        elif not any(char.isupper() for char in password):
                messagebox.showerror("Error", "Password must contain at least one uppercase letter.")
        else:
        # Insert registration data into database
                sql = "INSERT INTO login (username, email, password) VALUES (%s, %s, %s)"
                val = (username, email, password)
                mycursor.execute(sql, val)
                mydb.commit()

        messagebox.showinfo("Success", "Registration successful!")

if __name__ == "__main__":
        main_window = tk.Tk()
        main_window.title("Login and Registration App")
        main_window.geometry("400x300")

        btnlogin = tk.Button(main_window, text="Login", command=LoginWindow)
        btnlogin.grid(row=0, column=0, padx=10, pady=10)

        btnregister = tk.Button(main_window, text="Register", command=RegisterWindow)
        btnregister.grid(row=0, column=1, padx=10, pady=10)

        main_window.mainloop()

