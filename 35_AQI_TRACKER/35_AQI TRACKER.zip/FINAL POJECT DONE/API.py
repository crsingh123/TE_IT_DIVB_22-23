import pyowm
owm = pyowm.OWM('13396e2da2b93d0b4b2c526651854212')

