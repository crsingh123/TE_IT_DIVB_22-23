#   FINAL PROJECT DONE




#  python -m streamlit run accuracy.py
















import streamlit as st
import numpy as np
import sklearn
from sklearn import datasets
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

import seaborn as sns
from sklearn.svm import SVC

from sklearn.neighbors import KNeighborsClassifier

import streamlit as st


import pandas as pd
import numpy as np

import streamlit as st
import matplotlib.pyplot as plt
from matplotlib import dates
from datetime import datetime
from matplotlib import rcParams
from API import owm
from pyowm.commons.exceptions import NotFoundError


import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")



st.write("""
# Explore different classifier
""")
dataset_name = st.sidebar.selectbox("Select Dataset",("weatherHistory","DailyDelhiClimateTrain"))
st.write(f"## Name of the Dataset: {dataset_name}")
classifier_name = st.sidebar.selectbox("Select Classifier",("KNN","SVM","Random Forest"))

def get_dataset(dataset_name):
    if dataset_name == "weatherHistory":
        data = datasets.load_iris()
    else:
        data = datasets.load_DailyDelhiClimateTrain()
    X = data.data
    y = data.target
    return X,y

X, y = get_dataset(dataset_name)
# st.write("## Shape of Dataset:",X.shape)
# st.write("## Number of classes:",len(np.unique(y)))

def add_parameter_ui(classifier_name):
    params = dict()
    if classifier_name == "KNN":
        K = st.sidebar.slider("K",1,15)
        params["K"] = K
    elif classifier_name == "SVM":
        C = st.sidebar.slider("C",0.01,10.0)
        params["C"] = C
    elif classifier_name == "Random Forest":
        max_depth = st.sidebar.slider("max_depth",2,15)
        n_estimators = st.sidebar.slider("n_estimators",1,100)
        params["max_depth"] = max_depth
        params["n_estimators"] = n_estimators
    return params

params = add_parameter_ui(classifier_name)

def get_classifier(classifier_name, params):
    if classifier_name == "KNN":
        classifier = KNeighborsClassifier(n_neighbors=params["K"])
    elif classifier_name == "SVM":
        classifier = SVC(C=params["C"])
    elif classifier_name == "Random Forest":
        classifier = RandomForestClassifier(n_estimators=params["n_estimators"],max_depth=params["max_depth"],random_state=1234)
    return classifier

classifier = get_classifier(classifier_name,params)

X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.2, random_state = 1234)

classifier.fit(X_train,y_train)
y_pred = classifier.predict(X_test)

accuracy_score = accuracy_score(y_test, y_pred)

st.write(f"## Classifier = {classifier_name}")
st.write(f"## Accuracy = {accuracy_score}")

# pca = PCA(2)
# X_projected = pca.fit_transform(X)

# x1 = X_projected[:,0]
# x2 = X_projected[:,1]

# fig = plt.figure()
# plt.scatter(x1,x2,c=y,alpha=0.8,cmap = "viridis")
# plt.xlabel("Principal Component 1")
# plt.ylabel("Principal Component 2")
# plt.colorbar()

# st.pyplot(fig)

# weatherHistory=pd.read_csv("weatherHistory.csv")
# st.write(weatherHistory.head())

# temp=pd.DataFrame(weatherHistory['Humidity'].value_counts()).head(50)
# st.bar_chart(temp)





# #    Bar Chart
# st.bar_chart(weatherHistory['Temperature (C)'].value_counts())
# st.bar_chart(weatherHistory['Wind Bearing (degrees)'].value_counts())
# st.bar_chart(weatherHistory['Daily Summary'].value_counts())
# st.bar_chart(weatherHistory['Pressure (millibars)'].value_counts())

# # line chart

# df = pd.DataFrame(weatherHistory[:600], columns = ['Wind Speed (km/h)','Humidity','Pressure (millibars)', 'Wind Bearing (degrees)'])
# df.hist()
# plt.show()
# st.pyplot()

# st.line_chart(df)

# # area chart
# chart_data = pd.DataFrame(weatherHistory[:400], columns=['Temperature (C)','Humidity','Pressure (millibars)', 'Wind Bearing (degrees)', 'Wind Speed (km/h)'])
# st.area_chart(chart_data)

# 






def main():


    activities = ["EDA", "Plots"]
    choice = st.sidebar.selectbox("Select Activities", activities)

    if choice == 'EDA':
        st.subheader("Exploratory Data Analysis")

        st.title(" ")
        st.title(" ")

        data = st.file_uploader("Upload a Dataset", type=["csv", "txt"])
        if data is not None:
            df = pd.read_csv(data)
            st.dataframe(df.head())

            if st.checkbox("Show Shape"):
                st.write(df.shape)

            if st.checkbox("Show Columns"):
                all_columns = df.columns.to_list()
                st.write(all_columns)

            if st.checkbox("Summary"):
                st.write(df.describe())

            if st.checkbox("Show Selected Columns"):
                selected_columns = st.multiselect(
                    "Select Columns", all_columns)
                new_df = df[selected_columns]
                st.dataframe(new_df)

            if st.checkbox("Show Value Counts"):
                st.write(df.iloc[:, -1].value_counts())

            if st.checkbox("Correlation Plot(Matplotlib)"):
                plt.matshow(df.corr())
                st.pyplot()

            if st.checkbox("Correlation Plot(Seaborn)"):
                st.write(sns.heatmap(df.corr(), annot=True))
                st.pyplot()

            if st.checkbox("Pie Plot"):
                all_columns = df.columns.to_list()
                column_to_plot = st.selectbox("Select 1 Column", all_columns)
                pie_plot = df[column_to_plot].value_counts().plot.pie(
                    autopct="%1.1f%%")
                st.write(pie_plot)
                st.pyplot()

    elif choice == 'Plots':
        st.subheader("Data Visualization")
        data = st.file_uploader("Upload a Dataset", type=["csv", "txt"])
        if data is not None:
            df = pd.read_csv(data)
            st.dataframe(df.head())

            if st.checkbox("Show Value Counts"):
                st.write(df.iloc[:, -1].value_counts().plot(kind='bar'))
                st.pyplot()

            # Customizable Plot

            all_columns_names = df.columns.tolist()
            type_of_plot = st.selectbox("Select Type of Plot", [
                                        "area", "bar", "line", "hist", "box", "kde"])
            selected_columns_names = st.multiselect(
                "Select Columns To Plot", all_columns_names)

            if st.button("Generate Plot"):
                st.success("Generating Customizable Plot of {} for {}".format(
                    type_of_plot, selected_columns_names))

                # Plot By Streamlit
                if type_of_plot == 'area':
                    cust_data = df[selected_columns_names]
                    st.area_chart(cust_data)

                elif type_of_plot == 'bar':
                    cust_data = df[selected_columns_names]
                    st.bar_chart(cust_data)

                elif type_of_plot == 'line':
                    cust_data = df[selected_columns_names]
                    st.line_chart(cust_data)

                # Custom Plot
                elif type_of_plot:
                    cust_plot = df[selected_columns_names].plot(
                        kind=type_of_plot)
                    st.write(cust_plot)
                    st.pyplot()

 
    # elif choice == 'About':
    #     st.subheader("About")


if __name__ == '__main__':
    main()


st.title(" ")
st.title(" ")
st.title("  WEATHER FORECASTER  ")

col1, mid, col2 = st.beta_columns([80, 5, 140])
# with col1:
#     st.write('##  ️MADE BY - ')
with col1:
    st.image('india.jpg', width=50)

st.header("🌐 Enter the name of City and Select Temperature Unit")
place = st.text_input("NAME OF THE CITY 🌆 ", " ")
unit = st.selectbox(" SELECT TEMPERATURE UNIT 🌡 ", ("Celsius", "Fahrenheit"))
g_type = st.selectbox("SELECT GRAPH TYPE 📉 ", ("Line Graph", "Bar Graph"))
b = st.button("SUBMIT")

# To deceive error of pyplot global warning
st.set_option('deprecation.showPyplotGlobalUse', False)

def plot_line(days, min_t, max_t):
    days = dates.date2num(days)
    rcParams['figure.figsize'] = 6, 4
    plt.plot(days, max_t, color='black', linestyle='solid', linewidth=1, marker='o', markerfacecolor='green',
             markersize=7)
    plt.plot(days, min_t, color='black', linestyle='solid', linewidth=1, marker='o', markerfacecolor='blue',
             markersize=7)
    plt.ylim(min(min_t) - 4, max(max_t) + 4)
    plt.xticks(days)
    x_y_axis = plt.gca()
    xaxis_format = dates.DateFormatter('%d/%m')

    x_y_axis.xaxis.set_major_formatter(xaxis_format)
    plt.grid(True, color='brown')
    plt.legend(["Maximum Temperature", "Minimum Temperature"], loc=1)
    plt.xlabel('Dates(dd/mm)')
    plt.ylabel('Temperature')
    plt.title('6-Day Weather Forecast')

    for i in range(5):
        plt.text(days[i], min_t[i] - 1.5, min_t[i],
                 horizontalalignment='center',
                 verticalalignment='bottom',
                 color='black')
    for i in range(5):
        plt.text(days[i], max_t[i] + 0.5, max_t[i],
                 horizontalalignment='center',
                 verticalalignment='bottom',
                 color='black')
    # plt.show()
    # plt.savefig('figure_line.png')
    st.pyplot()
    plt.clf()


def plot_bars(days, min_t, max_t):
    # print(days)
    days = dates.date2num(days)
    rcParams['figure.figsize'] = 6, 4
    min_temp_bar = plt.bar(days - 0.2, min_t, width=0.4, color='r')
    max_temp_bar = plt.bar(days + 0.2, max_t, width=0.4, color='b')
    plt.xticks(days)
    x_y_axis = plt.gca()
    xaxis_format = dates.DateFormatter('%d/%m')

    x_y_axis.xaxis.set_major_formatter(xaxis_format)
    plt.xlabel('Dates(dd/mm)')
    plt.ylabel('Temperature')
    plt.title('6-Day Weather Forecast')

    for bar_chart in [min_temp_bar, max_temp_bar]:
        for index, bar in enumerate(bar_chart):
            height = bar.get_height()
            xpos = bar.get_x() + bar.get_width() / 2.0
            ypos = height
            label_text = str(int(height))
            plt.text(xpos, ypos, label_text,
                     horizontalalignment='center',
                     verticalalignment='bottom',
                     color='black')
    st.pyplot()
    plt.clf()


# Main function
def weather_detail(place, unit, g_type):
    mgr = owm.weather_manager()
    days = []
    dates_2 = []
    min_t = []
    max_t = []
    forecaster = None
    forecast = None
    try:
        forecaster = mgr.forecast_at_place(place, '3h')
        forecast = forecaster.forecast
        obs = mgr.weather_at_place(place)
    except Exception as e:
        print(e)
        return
    weather = obs.weather
    temperature = weather.temperature(unit='celsius')['temp']
    if unit == 'Celsius':
        unit_c = 'celsius'
    else:
        unit_c = 'fahrenheit'

    for weather in forecast:
        day = datetime.utcfromtimestamp(weather.reference_time())
        date1 = day.date()
        if date1 not in dates_2:
            dates_2.append(date1)
            min_t.append(None)
            max_t.append(None)
            days.append(date1)
        temperature = weather.temperature(unit_c)['temp']
        if not min_t[-1] or temperature < min_t[-1]:
            min_t[-1] = temperature
        if not max_t[-1] or temperature > max_t[-1]:
            max_t[-1] = temperature

    obs = mgr.weather_at_place(place)
    weather = obs.weather
    st.title(f" Weather at {place[0].upper() + place[1:]} currently: ")
    if unit_c == 'celsius':
        st.write(f"## 🌡️ Temperature: {temperature} °C")
    else:
        st.write(f"## 🌡️  Temperature: {temperature} F")
    st.write(f"## ☁️ Sky: {weather.detailed_status}")
    st.write(f"## 🌪  Wind Speed: {round(weather.wind(unit='km_hour')['speed'])} km/h")
    st.write(f"### ⛅️Sunrise Time :     {weather.sunrise_time(timeformat='iso')} GMT")
    st.write(f"### ☁️  Sunset Time :      {weather.sunset_time(timeformat='iso')} GMT")

    # Expected Temperature Alerts
    st.title("❄️Expected Temperature Changes/Alerts: ")
    if forecaster.will_have_fog():
        st.write("### ▶️FOG ALERT🌁!!")
    if forecaster.will_have_rain():
        st.write("### ▶️RAIN ALERT☔!!")
    if forecaster.will_have_storm():
        st.write("### ▶️STORM ALERT⛈️!!")
    if forecaster.will_have_snow():
        st.write("### ▶️ SNOW ALERT❄️!!")
    if forecaster.will_have_tornado():
        st.write("### ▶️TORNADO ALERT🌪️!!")
    if forecaster.will_have_hurricane():
        st.write("### ▶️HURRICANE ALERT🌀")
    if forecaster.will_have_clear():
        st.write("### ▶️CLEAR WEATHER PREDICTED🌞!!")
    if forecaster.will_have_clouds():
        st.write("### ▶️CLOUDY SKIES⛅")

    st.write('                ')
    st.write('                ')

    if g_type == "Line Graph":
        plot_line(days, min_t, max_t)
    elif g_type == "Bar Graph":
        plot_bars(days, min_t, max_t)

    # To give max and min temperature
    i = 0
    st.write(f"# 📆 Date :  Max - Min  ({unit})")
    for obj in days:
        ta = (obj.strftime("%d/%m"))
        st.write(f'### ➡️ {ta} :\t   ({max_t[i]} - {min_t[i]})')
        i += 1


if b:
    if place != "":
        try:
            weather_detail(place, unit, g_type)

        except NotFoundError:
            st.write("Please enter a Valid city name")


